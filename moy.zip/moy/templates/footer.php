<footer class="footer mt-auto py-3 bg-dark text-white">
    <div class="container text-center">
        <p>Контакты: example@example.com | Телефон: 8(800)555-35-35</p>
    </div>
</footer>
</div>
<script src="https://code.jquery.com/jquery-3.5.1.slim.min.js"></script>
<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery.mask/1.14.16/jquery.mask.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.0/dist/umd/popper.min.js"></script>
<script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
<script>
$(document).ready(function() {
    $('#phone').mask('8(999)-999-99-99');
});
</script>
</body>
</html>