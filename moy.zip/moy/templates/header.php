<!DOCTYPE html>
<html lang="ru">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Мой Не Сам</title>
    <link href="https://fonts.googleapis.com/css2?family=Roboto:wght@400;700&display=swap" rel="stylesheet">
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link rel="stylesheet" href="../assets/css/styles.css">
</head>
<body>
    <div class="d-flex flex-column min-vh-100">
    <header class="header">
        <h1><a href="index.php" class="text-decoration-none text-white">Мой Не Сам</a></h1>
        <?php include 'nav.php'; ?>

        <div class="user-info">
            <?php if (isset($_SESSION['user_id'])): ?>
                <span>Привет, <?= htmlspecialchars($_SESSION['full_name'] ?? 'Гость') ?>!</span>
                <a href="logout.php" class="btn btn-danger">Выход</a>
            <?php else: ?>
                <a href="register.php" class="btn btn-primary">Регистрация</a>
                <a href="login.php" class="btn btn-primary">Вход</a>
            <?php endif; ?>
        </div>
    </header>
