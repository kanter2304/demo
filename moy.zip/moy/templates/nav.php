<nav class="navigation">
    <ul>
        <li><a href="index.php" class="btn btn-primary">Главная</a></li>
        <li><a href="requests.php" class="btn btn-primary">Мои заявки</a></li>
    </ul>
</nav>