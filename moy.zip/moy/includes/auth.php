<?php
session_start();

function check_auth() {
    return isset($_SESSION['user_id']);
}

function check_admin() {
    return isset($_SESSION['admin']);
}
?>