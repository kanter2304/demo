<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

$error_message = '';
$success_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $full_name = $_POST['full_name'];
    $phone = $_POST['phone'];
    $email = $_POST['email'];
    $username = $_POST['username'];
    $password = $_POST['password'];

    if (!preg_match('/^8\(\d{3}\)-\d{3}-\d{2}-\d{2}$/', $phone)) {
        $error_message = "❌ Неверный формат номера телефона. Используйте: 8(XXX)-XXX-XX-XX.";
    } elseif (strlen($password) < 6) {
        $error_message = "❌ Пароль должен содержать минимум 6 символов.";
    } else {
        $password_hashed = password_hash($password, PASSWORD_DEFAULT);
        $sql = 'INSERT INTO Users (full_name, phone, email, username, password) VALUES (?, ?, ?, ?, ?)';
        $stmt = $connection->prepare($sql);

        try {
            $stmt->execute([$full_name, $phone, $email, $username, $password_hashed]);
            $success_message = "✅ Регистрация прошла успешно! Перенаправление...";
            header("refresh:2;url=login.php");
        } catch (PDOException $e) {
            if ($e->getCode() == 23000) {
                if (strpos($e->getMessage(), 'email') !== false) {
                    $error_message = "❌ Пользователь с таким email уже существует.";
                } elseif (strpos($e->getMessage(), 'phone') !== false) {
                    $error_message = "❌ Пользователь с таким номером телефона уже существует.";
                } elseif (strpos($e->getMessage(), 'username') !== false) {
                    $error_message = "❌ Пользователь с таким логином уже существует.";
                } else {
                    $error_message = "❌ Ошибка: уже существует запись с таким уникальным значением.";
                }
            } else {
                $error_message = "❌ Ошибка регистрации: " . $e->getMessage();
            }
        }
    }
}
?>

<?php include '../templates/header.php'; ?>

<style>
.message {
    padding: 15px 20px;
    margin-bottom: 20px;
    border-radius: 6px;
    font-size: 16px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}
.success-message {
    background-color: #e6f9ec;
    color: #2b7a3f;
    border: 1px solid #b4e2c1;
}
.error-message {
    background-color: #fdecea;
    color: #a94442;
    border: 1px solid #f5c6cb;
}
</style>

<main class="container">
    <h2>Регистрация</h2>

    <?php if (!empty($success_message)): ?>
        <div class="message success-message"><?= htmlspecialchars($success_message) ?></div>
    <?php endif; ?>

    <?php if (!empty($error_message)): ?>
        <div class="message error-message"><?= htmlspecialchars($error_message) ?></div>
    <?php endif; ?>

    <form action="register.php" method="POST">
        <div class="form-group">
            <label for="full_name">ФИО:</label>
            <input type="text" class="form-control" id="full_name" name="full_name" required>
        </div>

        <div class="form-group">
            <label for="phone">Телефон:</label>
            <input type="text" class="form-control" id="phone" name="phone" required placeholder="8(XXX)-XXX-XX-XX">
        </div>

        <div class="form-group">
            <label for="email">Email:</label>
            <input type="email" class="form-control" id="email" name="email" required>
        </div>

        <div class="form-group">
            <label for="username">Логин:</label>
            <input type="text" class="form-control" id="username" name="username" required>
        </div>

        <div class="form-group">
            <label for="password">Пароль:</label>
            <input type="password" class="form-control" id="password" name="password" required minlength="6">
        </div>

        <button type="submit" class="btn btn-primary">Зарегистрироваться</button>
    </form>
</main>

<script src="https://cdn.jsdelivr.net/npm/inputmask@5.0.8/dist/inputmask.min.js"></script>
<script>
document.addEventListener('DOMContentLoaded', function () {
    const phoneInput = document.getElementById("phone");
    if (typeof Inputmask !== 'undefined') {
        Inputmask({
            mask: "8(999)-999-99-99",
            showMaskOnHover: false,
            showMaskOnFocus: true,
            inputmode: "numeric"
        }).mask(phoneInput);
    }
});
</script>

<?php include '../templates/footer.php'; ?>
