<?php include '../includes/auth.php'; ?>
<?php include '../templates/header.php'; ?>

<main class="container mt-4">
    <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
        <div class="carousel-inner">
            <div class="carousel-item active">
                <img src="../assets/images/1.jpg" class="d-block w-100" alt="Автомобиль 1">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Ваша чистота — наша миссия</h5>
                    <p>Мы заботимся о вашем комфорте и здоровье в каждом уголке вашего дома.</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="../assets/images/2.jpg" class="d-block w-100" alt="Автомобиль 2">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Профессионализм и качество</h5>
                    <p>От глубокой чистки до поддержания порядка — мы сделаем всё для вас!</p>
                </div>
            </div>
            <div class="carousel-item">
                <img src="../assets/images/3.jpg" class="d-block w-100" alt="Автомобиль 3">
                <div class="carousel-caption d-none d-md-block">
                    <h5>Создайте идеальную атмосферу</h5>
                    <p>Доверьте уборку профессионалам и наслаждайтесь свободным временем.</p>
                </div>
            </div>
        </div>
        <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
            <span class="carousel-control-prev-icon" aria-hidden="true"></span>
            <span class="sr-only">Previous</span>
        </a>
        <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
            <span class="carousel-control-next-icon" aria-hidden="true"></span>
            <span class="sr-only">Next</span>
        </a>
    </div>

    <section class="text-center my-5">
        <h2>Наш девиз</h2>
        <p class="lead">"Чистота — залог вашего комфорта!"</p>
    </section>

    <section>
        <h2 class="text-center">Каталог услуг</h2>
        <div class="row">
                <div class="col-md-4 mb-4">
            <div class="card">
                <img src="../assets/images/1.jpg" class="card-img-top" alt="Услуга 1">
                <div class="card-body">
                    <h5 class="card-title">Генеральная уборка</h5>
                    <p class="card-text">Полная очистка вашего пространства для создания свежей и уютной атмосферы.</p>
                    <a href="#" class="btn btn-primary">Подробнее</a>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card">
                <img src="../assets/images/2.jpg" class="card-img-top" alt="Услуга 2">
                <div class="card-body">
                    <h5 class="card-title">Общий клининг</h5>
                    <p class="card-text">Комплексная уборка, которая придаст вашему дому идеальную чистоту.</p>
                    <a href="#" class="btn btn-primary">Подробнее</a>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card">
                <img src="../assets/images/2.jpg" class="card-img-top" alt="Услуга 3">
                <div class="card-body">
                    <h5 class="card-title">Химчистка ковров и мебели</h5>
                    <p class="card-text">Глубокая очистка текстильных поверхностей для восстановления их первоначального вида.</p>
                    <a href="#" class="btn btn-primary">Подробнее</a>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card">
                <img src="../assets/images/3.jpg" class="card-img-top" alt="Услуга 4">
                <div class="card-body">
                    <h5 class="card-title">Послестроительная уборка</h5>
                    <p class="card-text">Удаление строительного мусора и пыли для готовности вашего нового пространства.</p>
                    <a href="#" class="btn btn-primary">Подробнее</a>
                </div>
            </div>
        </div>

        <div class="col-md-4 mb-4">
            <div class="card">
                <img src="../assets/images/2.jpg" class="card-img-top" alt="Услуга 5">
                <div class="card-body">
                    <h5 class="card-title">Иные услуги</h5>
                    <p class="card-text">Гибкие решения для любых нужд по уборке, адаптированные под ваши требования.</p>
                    <a href="#" class="btn btn-primary">Подробнее</a>
                </div>
            </div>
        </div>
        </div>
    </section>
</main>
<?php include '../templates/footer.php'; ?>