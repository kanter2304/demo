<?php

require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

if (!check_auth()) {
    redirect('login.php');
}


$user_id = $_SESSION['user_id'];

$sql = 'SELECT r.id, r.requested_date, r.status, r.cancellation_reason, s.service_name 
        FROM Requests r 
        LEFT JOIN Services s ON r.service_id = s.id 
        WHERE r.user_id = ?';

$stmt = $connection->prepare($sql);
$stmt->execute([$user_id]);
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<?php include '../templates/header.php'; ?>

<main class="container">
    <h2>Мои заявки</h2>
    <table class="table">
        <thead>
            <tr>
                <th>Дата заявки</th>
                <th>Услуга</th>
                <th>Статус</th>
                <th>Причина отмены</th>
            </tr>
        </thead>
        <tbody>
            <?php if (empty($requests)): ?>
                <tr>
                    <td colspan="4">У вас нет активных заявок.</td>
                </tr>
            <?php else: ?>
                <?php foreach ($requests as $request): ?>
                    <tr>
                        <td><?= htmlspecialchars($request['requested_date']) ?></td>
                        <td><?= htmlspecialchars($request['service_name'] ?? 'Иная услуга') ?></td>
                        <td><?= htmlspecialchars($request['status']) ?></td>
                        <td><?= htmlspecialchars($request['cancellation_reason'] ?? 'Нет') ?></td> <!-- Отображение причины отмены -->
                    </tr>
                <?php endforeach; ?>
            <?php endif; ?>
        </tbody>
    </table>

    <button onclick="location.href='create_request.php'" class="btn btn-primary">Создать заявку</button>
</main>

<?php include '../templates/footer.php'; ?>