<?php
require_once '../includes/db.php';
require_once '../includes/functions.php';

session_start();

$error_message = '';
$success_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $email_or_username = $_POST['email_or_login'];
    $password = $_POST['password'];

    if ($email_or_username === 'adminka' && $password === 'password') {
        $_SESSION['admin'] = true;
        $success_message = "✅ Вы успешно вошли как администратор. Перенаправление...";
        header("refresh:2;url=admin.php");
    } else {
        $sql = 'SELECT * FROM Users WHERE email = ? OR username = ?';
        $stmt = $connection->prepare($sql);
        $stmt->execute([$email_or_username, $email_or_username]);
        $user = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($user && password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['full_name'] = $user['full_name'];
            $success_message = "✅ Добро пожаловать, " . htmlspecialchars($user['full_name']) . ". Перенаправление...";
            header("refresh:2;url=requests.php");
        } else {
            $error_message = "❌ Неправильный email или пароль.";
        }
    }
}
?>

<?php include '../templates/header.php'; ?>

<style>
.message {
    padding: 15px 20px;
    margin-bottom: 20px;
    border-radius: 6px;
    font-size: 16px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}
.success-message {
    background-color: #e6f9ec;
    color: #2b7a3f;
    border: 1px solid #b4e2c1;
}
.error-message {
    background-color: #fdecea;
    color: #a94442;
    border: 1px solid #f5c6cb;
}
</style>

<main class="container">
    <h2>Вход</h2>

    <?php if (!empty($success_message)): ?>
        <div class="message success-message"><?= htmlspecialchars($success_message) ?></div>
    <?php endif; ?>

    <?php if (!empty($error_message)): ?>
        <div class="message error-message"><?= htmlspecialchars($error_message) ?></div>
    <?php endif; ?>

    <form action="login.php" method="POST">
        <div class="form-group">
            <label for="email_or_login">Email или Логин:</label>
            <input type="text" id="email_or_login" name="email_or_login" required>
        </div>
        <div class="form-group">
            <label for="password">Пароль:</label>
            <input type="password" id="password" name="password" required>
        </div>
        <button type="submit" class="btn btn-primary">Войти</button>
    </form>
</main>

<?php include '../templates/footer.php'; ?>
