<?php
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);

require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

if (!check_auth()) {
    redirect('login.php');
}

$sql = 'SELECT id, service_name FROM services';
$stmt = $connection->query($sql);
$services = $stmt->fetchAll(PDO::FETCH_ASSOC);

$success_message = '';
$error_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $user_id = $_SESSION['user_id'];
    $service_id = $_POST['service'] ?? null;
    $custom_service_description = '';
    $address = $_POST['address'];
    $contact_phone = $_POST['contact_phone'];
    $requested_date = $_POST['requested_date'];
    $preferred_payment = $_POST['preferred_payment'] ?? null;

    if (!preg_match('/^8\(\d{3}\)-\d{3}-\d{2}-\d{2}$/', $contact_phone)) {
        $error_message = "❌ Неверный формат номера телефона. Используйте: 8(XXX)-XXX-XX-XX.";
    } elseif ($preferred_payment !== 'наличные' && $preferred_payment !== 'банковская карта') {
        $error_message = "❌ Неверный тип оплаты.";
    } elseif ($service_id === 'other') {
        $custom_service_description = $_POST['custom_service_description'] ?? '';
        if (empty($custom_service_description)) {
            $error_message = "❌ Пожалуйста, укажите описание для иной услуги.";
        } else {
            $service_id = null;
        }
    } elseif (!is_numeric($service_id)) {
        $error_message = "❌ Неверный идентификатор услуги.";
    }

    if (empty($error_message)) {
        $sql = 'SELECT * FROM requests WHERE service_id = ? AND requested_date = ? AND (status = "в работе" OR status = "выполнено")';
        $stmt = $connection->prepare($sql);
        $stmt->execute([$service_id, $requested_date]);
        $existing_request = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($existing_request) {
            $error_message = "❌ Услуга уже забронирована на эту дату.";
        } else {
            $status = 'в работе';

            $sql = 'INSERT INTO requests (user_id, address, contact_phone, service_id, custom_service_description, preferred_payment, requested_date, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?)';
            $stmt = $connection->prepare($sql);
            $stmt->execute([$user_id, $address, $contact_phone, $service_id, $custom_service_description, $preferred_payment, $requested_date, $status]);

            $success_message = "✅ Заявка успешно создана!";
        }
    }
}
?>

<?php include '../templates/header.php'; ?>

<style>
.message {
    padding: 15px 20px;
    margin-bottom: 20px;
    border-radius: 6px;
    font-size: 16px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}

.success-message {
    background-color: #e6f9ec;
    color: #2b7a3f;
    border: 1px solid #b4e2c1;
}

.error-message {
    background-color: #fdecea;
    color: #a94442;
    border: 1px solid #f5c6cb;
}
</style>

<main class="container">
    <h2>Создать заявку</h2>

    <?php if (!empty($success_message)): ?>
        <div class="message success-message">
            <?= htmlspecialchars($success_message) ?>
        </div>
    <?php endif; ?>

    <?php if (!empty($error_message)): ?>
        <div class="message error-message">
            <?= htmlspecialchars($error_message) ?>
        </div>
    <?php endif; ?>

    <form action="create_request.php" method="POST">
        <div class="form-group">
            <label for="service">Услуга:</label>
            <select id="service" name="service" required onchange="toggleOtherService(this)">
                <option value="" disabled selected>Выберите услугу</option>
                <?php foreach ($services as $srv): ?>
                    <option value="<?= htmlspecialchars($srv['id']) ?>"><?= htmlspecialchars($srv['service_name']) ?></option>
                <?php endforeach; ?>
                <option value="other">Иная услуга</option>
            </select>
        </div>

        <div class="form-group" id="other_service_container" style="display:none;">
            <label for="custom_service_description">Описание иной услуги:</label>
            <input type="text" id="custom_service_description" name="custom_service_description" placeholder="Укажите услугу" />
        </div>

        <div class="form-group">
            <label for="address">Адрес:</label>
            <input type="text" id="address" name="address" required />
        </div>

        <div class="form-group">
            <label for="contact_phone">Контактный телефон:</label>
            <input type="tel" id="contact_phone" name="contact_phone" required placeholder="8(XXX)-XXX-XX-XX" />
        </div>

        <div class="form-group">
            <label for="requested_date">Дата бронирования:</label>
            <input type="date" id="requested_date" name="requested_date" required>
        </div>

        <div class="form-group">
            <label>Предпочитаемый тип оплаты:</label>
            <div>
                <label><input type="radio" name="preferred_payment" value="наличные" required> Наличные</label>
            </div>
            <div>
                <label><input type="radio" name="preferred_payment" value="банковская карта" required> Банковская карта</label>
            </div>
        </div>

        <button type="submit" class="btn btn-primary">Подать заявку</button>
    </form>
</main>

<script src="https://cdn.jsdelivr.net/npm/inputmask@5.0.8/dist/inputmask.min.js"></script>
<script>
    function toggleOtherService(select) {
        const otherServiceContainer = document.getElementById('other_service_container');
        otherServiceContainer.style.display = select.value === 'other' ? 'block' : 'none';
    }

    document.addEventListener('DOMContentLoaded', function () {
        const phoneInput = document.getElementById("contact_phone");

        if (typeof Inputmask !== 'undefined') {
            Inputmask({
                mask: "8(999)-999-99-99",
                showMaskOnHover: false,
                showMaskOnFocus: true,
                inputmode: "numeric"
            }).mask(phoneInput);
        } else {
            console.error("Inputmask не загружен!");
        }
    });
</script>

<?php include '../templates/footer.php'; ?>
