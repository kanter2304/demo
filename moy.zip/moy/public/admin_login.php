<?php
require_once '../includes/functions.php';

session_start();

if ($_SERVER["REQUEST_METHOD"] == "POST") {
    $login = $_POST['login'];
    $password = $_POST['password'];

    if ($login === 'car' && $password === 'carforme') {
        $_SESSION['admin'] = true;
        redirect('admin.php');
    } else {
        echo "Неправильный логин или пароль";
    }
}
?>

<?php include '../templates/header.php'; ?>
<main>
    <h2>Вход для администратора</h2>
    <form action="admin_login.php" method="POST">
        <label for="login">Логин:</label>
        <input type="text" id="login" name="login" required>
        
        <label for="password">Пароль:</label>
        <input type="password" id="password" name="password" required>
        
        <button type="submit" class="btn btn-primary">Войти</button>
    </form>
</main>
<?php include '../templates/footer.php'; ?>