<?php

require_once '../includes/db.php';
require_once '../includes/functions.php';
require_once '../includes/auth.php';

if (!check_admin()) {
    redirect('admin_login.php');
}

$error_message = '';
$success_message = '';

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['request_id']) && isset($_POST['status'])) {
    $request_id = $_POST['request_id'];
    $status = $_POST['status'];
    $cancellation_reason = $_POST['cancellation_reason'] ?? null;

    if ($status === 'отменено' && empty($cancellation_reason)) {
        $error_message = "❌ Пожалуйста, укажите причину отмены.";
    } else {
        $sql = 'UPDATE Requests SET status = ?, cancellation_reason = ? WHERE id = ?';
        $stmt = $connection->prepare($sql);
        $stmt->execute([$status, $cancellation_reason, $request_id]);

        $success_message = "✅ Статус заявки успешно обновлен!";
    }
}

$sql = 'SELECT r.id, u.full_name, u.phone, u.email, r.address, r.requested_date, r.service_id, r.status, r.cancellation_reason 
        FROM Requests r 
        JOIN Users u ON r.user_id = u.id';

$stmt = $connection->query($sql);
$requests = $stmt->fetchAll(PDO::FETCH_ASSOC);

$sql_services = 'SELECT id, service_name FROM Services';
$stmt_services = $connection->query($sql_services);
$services = $stmt_services->fetchAll(PDO::FETCH_ASSOC);

$services_map = [];
foreach ($services as $service) {
    $services_map[$service['id']] = $service['service_name'];
}

?>

<?php include '../templates/header.php'; ?>

<style>
.message {
    padding: 15px 20px;
    margin-bottom: 20px;
    border-radius: 6px;
    font-size: 16px;
    box-shadow: 0 2px 4px rgba(0,0,0,0.1);
}
.success-message {
    background-color: #e6f9ec;
    color: #2b7a3f;
    border: 1px solid #b4e2c1;
}
.error-message {
    background-color: #fdecea;
    color: #a94442;
    border: 1px solid #f5c6cb;
}
</style>

<main class="container">
    <h2>Панель администратора</h2>

    <?php if (!empty($success_message)): ?>
        <div class="message success-message"><?= htmlspecialchars($success_message) ?></div>
    <?php endif; ?>

    <?php if (!empty($error_message)): ?>
        <div class="message error-message"><?= htmlspecialchars($error_message) ?></div>
    <?php endif; ?>

    <table class="table table-striped">
        <thead>
            <tr>
                <th>ФИО</th>
                <th>Телефон</th>
                <th>Email</th>
                <th>Адрес</th>
                <th>Дата заявки</th>
                <th>Услуга</th>
                <th>Статус</th>
                <th>Действие</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($requests as $request): ?>
                <tr>
                    <td><?= htmlspecialchars($request['full_name']) ?></td>
                    <td><?= htmlspecialchars($request['phone']) ?></td>
                    <td><?= htmlspecialchars($request['email']) ?></td>
                    <td><?= htmlspecialchars($request['address']) ?></td>
                    <td><?= htmlspecialchars($request['requested_date']) ?></td>
                    <td><?= htmlspecialchars($services_map[$request['service_id']] ?? 'Не указана') ?></td>
                    <td><?= htmlspecialchars($request['status']) ?></td>
                    <td>
                        <?php if ($request['status'] == 'в работе'): ?>
                            <form method="POST">
                                <input type="hidden" name="request_id" value="<?= $request['id'] ?>">
                                <select name="status">
                                    <option value="выполнено">Выполнить</option>
                                    <option value="отменено">Отменить</option>
                                </select>
                                <input type="text" name="cancellation_reason" placeholder="Причина отмены" style="display:none;" id="reason_<?= $request['id'] ?>">
                                <button type="submit">Изменить</button>
                            </form>
                            <script>
                                const selectElement = document.querySelector('select[name="status"]');
                                selectElement.addEventListener('change', function() {
                                    const reasonInput = document.getElementById('reason_<?= $request['id'] ?>');
                                    reasonInput.style.display = this.value === 'отменено' ? 'inline' : 'none';
                                });
                            </script>
                        <?php endif; ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</main>

<?php include '../templates/footer.php'; ?>
